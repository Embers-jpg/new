
const startButton = document.getElementById('start-button');
const startScreen = document.getElementById('start-screen');
const gameCanvas = document.getElementById('game-canvas');
const ctx = gameCanvas.getContext('2d');

gameCanvas.width = 800;
gameCanvas.height = 600;

startButton.addEventListener('click', () => {
    startScreen.style.display = 'none';
    startGame();
});

function startGame() {
    ctx.fillStyle = 'red';
    ctx.fillRect(50, 50, 50, 50);
}
